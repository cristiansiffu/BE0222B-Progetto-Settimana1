public class Macchina {
	private String nome;
	private int cilindrata;
	private String targa;
	private int prezzo;
	private String colore;
	private int numeroMarce;
	private boolean motoreAcceso;
	private int marcia;

	Macchina(String nome, int cilindrata, String targa, int prezzo, String colore, int numeroMarce) {
		this.nome = nome;
		this.cilindrata = cilindrata;
		this.targa = targa;
		this.prezzo = prezzo;
		this.colore = colore;
		this.numeroMarce = numeroMarce;
		this.motoreAcceso = false;
		this.marcia = 0;
	}

	public void accendiMotore() {
		if (this.motoreAcceso == false) {
			this.motoreAcceso = true;
			this.marcia = 0;
			System.out.println("Il motore � acceso");
		} else {
			System.out.println("Il motore � gi� acceso");
		}
	}

	public void spegniMotore() {
		if (this.motoreAcceso == true) {
			this.motoreAcceso = false;
			this.marcia = 0;
			System.out.println("Il motore � spento");
		} else {
			System.out.println("Il motore � gi� spento");
		}
	}

	public void cambiaMarcia(int numeroMarcia) {
		if (numeroMarcia >= 0 && marcia <= this.numeroMarce) {
			this.marcia = numeroMarcia;
			System.out.println("Marcia inserita");
		} else {
			System.out.println("La marcia inserita non esiste.");
		}
	}

	public void scalaMarcia() {
		if (this.marcia > 0) {
			this.marcia--;
			System.out.println("Marcia scalata");
		} else {
			System.out.println("Impossibile scalare marcia");
		}
	}

	public void aumentaMarcia() {
		if (this.marcia < this.numeroMarce) {
			this.marcia++;
			System.out.println("Marcia aumentata");
		} else {
			System.out.println("Impossibile aumentare marcia");
		}
	}

	public int getValore() {
		System.out.println("Prezzo: " + this.prezzo);
		return this.prezzo;
	}

	public void stampaInformazioni() {
		System.out.println("Nome:" + this.nome + "\n" + "Cilindrata: " + this.cilindrata + "\n" + "Targa: "
				+ this.getTarga() + "\n" + "Prezzo: " + this.prezzo + "\n" + "Colore: " + this.getColore());
	}

	public String getColore() {
		return colore;
	}

	public String getTarga() {
		return targa;
	}

}
