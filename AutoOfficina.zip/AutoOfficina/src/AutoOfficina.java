public class AutoOfficina {

	public static void main(String[] args) {
		Macchina alphaRomeo147 = new Macchina("147", 1900, "abc123def", 15000, "nera", 5);
		Macchina alphaRomeoGiulia = new Macchina("Giulia", 1700, "mnb999vcx", 18000, "bianca", 4);
		Macchina alphaRomeoMito = new Macchina("Mito", 1200, "qwe345rty", 11000, "rossa", 6);
		Macchina alphaRomeo159 = new Macchina("159", 900, "rty123qwe", 9000, "blu", 3);
		Macchina alphaRomeoStelvio = new Macchina("Stelvio", 100000, "cba321fed", 40000, "rosa", 8);

		Macchina[] automobile = { alphaRomeo147, alphaRomeoGiulia, alphaRomeoMito, alphaRomeo159, alphaRomeoStelvio };

		alphaRomeo147.accendiMotore();
		alphaRomeo147.spegniMotore();
		alphaRomeo147.cambiaMarcia(3);
		alphaRomeo147.scalaMarcia();
		alphaRomeo147.aumentaMarcia();
		alphaRomeo147.getValore();
		alphaRomeo147.stampaInformazioni();
		infoMacchinaPiuCostosa(automobile);
		infoMacchina(automobile, "cba321fed");
		infoMacchinaColore(automobile, "rosa");
	}

	static void infoMacchinaPiuCostosa(Macchina[] automobile) {
		Macchina macchinaPiuCostosa = automobile[0];
		for (int i = 0; i < automobile.length; i++) {
			if (automobile[i].getValore() > macchinaPiuCostosa.getValore()) {
				macchinaPiuCostosa = automobile[i];
			}
		}
		macchinaPiuCostosa.stampaInformazioni();
	}

	static void infoMacchina(Macchina[] automobile, String targa) {
		Macchina targaMacchina = null;
		for (int i = 0; i < automobile.length; i++) {
			if (automobile[i].getTarga().toUpperCase().equals(targa.toUpperCase())) {
				targaMacchina = automobile[i];
			}
		}
		targaMacchina.stampaInformazioni();
	}

	static void infoMacchinaColore(Macchina[] automobile, String colore) {
		Macchina coloreMacchina = null;
		for (int i = 0; i < automobile.length; i++) {
			if (automobile[i].getColore().toUpperCase().equals(colore.toUpperCase())) {
				coloreMacchina = automobile[i];
			}
		}
		coloreMacchina.stampaInformazioni();
	}
}
